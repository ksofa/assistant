package forhack.hack.dto;

import lombok.Data;

@Data
public class PayRequest {
    private String account;
    private String nameProvider;
}
